Jaden Towey 

002420751


Source Files:
- TotalPrice2.py
- Quadratic2.py


How to run your program/programs
python3 TotalPrice2.py
python3 Quadratic2.py


Sources:
N/A


Collaborators:
Ronan McDermott 
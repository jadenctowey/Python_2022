Jaden Towey 

002420751


Source Files:
- wordle.py
-words.txt


How to run your program/programs
python3 wordle.py



Sources:
N/A


Collaborators:
Ronan McDermott
Jaden Towey 

002420751

Source Files:
- TotalPrice.py
- Celsius.py
- Quadratic.py
- Seconds.py


How to run your program/programs
python3 TotalPrice.py
python3 Celsius.py
python3 Quadratic.py
python3 Seconds.py

Sources:
N/A

Collaborators:
Ronan McDermott 
